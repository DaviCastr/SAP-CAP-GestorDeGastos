sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{fechar:function(e){this.getParent().close()}}});
//# sourceMappingURL=TransacoesDaCategoria.js.map